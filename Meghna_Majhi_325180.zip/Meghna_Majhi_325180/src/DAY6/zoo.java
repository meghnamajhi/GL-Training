package DAY6;

public class zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		elephants e1=new elephants();
		elephants e2=new elephants();
		
		tiger t1=new tiger();
		tiger t2=new tiger();
		
		
		e1.color="Black";
		e1.food="Tree bark";
		e1.name=" ABC";
		e1.nol=4;
		e1.display_elephants(5,6);
		e1.eats();
		e1.swim();
		e1.walks();
		
		
		
		e2.color="Black";
		e2.food="twigs";
		
		e2.name="EDF";
		e2.nol=4;
		e2.display_elephants(4,5);
		e2.eats();
		e2.swim();
		e2.walks();
		
		t1.color="Red-Orange";
		t1.food="Deers";
		t1.gender="male";
		t1.name="Shere khan";
		t1.nol=4;
		t1.display_tiger(4,5,"f","4");
		t1.climb();
		t1.eats();
		t1.mauls();
		t1.roar();
		t1.walks();
		
		t2.color="White";
		t2.food="Fishes";
		t2.gender="male";
		t2.name="Richard Parker";
		t2.nol=4;
		t2.display_tiger(3,9,"M","8");
		t2.climb();
		t2.eats();
		t2.mauls();
		t2.roar();
		t2.walks();
	}

}
