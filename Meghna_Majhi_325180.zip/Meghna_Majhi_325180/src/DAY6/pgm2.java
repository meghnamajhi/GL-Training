package DAY6;
import java.util.ArrayList;

public class pgm2 {
	public static void main(String args[]) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("Meghna");
		System.out.println(al);
		al.add("Noida");
		al.add("Up");
		System.out.println(al);
		al.remove(1);
		System.out.println(al);
	}

}
