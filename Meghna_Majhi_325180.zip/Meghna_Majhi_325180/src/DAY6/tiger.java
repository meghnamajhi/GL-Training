package DAY6;

public class tiger extends animal {
	int lengthofteeth;
	int lenghtofclaw;
	public String gender;
	public String age;
	
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void mauls() {
		System.out.println("Tiger mauls its prey");
	}

	public void display_tiger(int lengthofteeth,int lenghtofclaw,String gender,String age) {
		// TODO Auto-generated method stub
		System.out.println(" No of legs: " +nol + " Skin color: "+ color + " Food: " + food + " Name: "+name 
				+ " Gender: " + gender + " Age: " + age );

		System.out.println(" Length of teeth : "+ lengthofteeth + " Length of claws : " + 
		lenghtofclaw);
		
	}
}
