package DAY6;

public class animal {
	int nol;
	String color;
	String food;
	String name;
	
	public void eats() {
		System.out.println("The animal eats:"+ food);
	}
	public void walks() {
		System.out.println("The animal walks");
	}
	public void display() {
		System.out.println("The no of legs" +this.nol +"Skin color" +this.color +"Food"+this.food+"Name"+this.name);
	}
	

}
