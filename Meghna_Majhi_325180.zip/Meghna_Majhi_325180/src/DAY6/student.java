package DAY6;

public class student {
	public String name;
	public int rollno;
	public int marks_java;
	public int marks_Selenium;
	public float avg;
	
	public void average() {
		this.avg=(this.marks_java+this.marks_Selenium)/2.0f;
		//return avg;
	}
	public student(String name,int rollno,int marks_java,int marks_Selenium) {
		this.name=name;
		this.rollno=rollno;
		this.marks_java=marks_java;
		this.marks_Selenium=marks_Selenium;
		this.average();
	}

}
