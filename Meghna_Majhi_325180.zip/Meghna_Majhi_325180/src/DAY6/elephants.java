package DAY6;

public class elephants extends animal{
	int lot;
	int lotusks;
	
	public void swim() {
		System.out.println("Elephant swim");
	}
	public void display_elephants(int lot,int lotusks) {
		System.out.println("The no of legs" +this.nol +"  Skin color" +this.color +" Food"+this.food+" Name"+this.name);
		System.out.println("Length of trunk: "+ lot+"Length of tusks "+lotusks);
	}

}
