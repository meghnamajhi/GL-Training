package DAY6;
import java.util.ArrayList;

public class ArrayList1 {
	ArrayList<student> a=new ArrayList<student>();
	public void create() {
		student s1=new student("Ram",101,75,80);
		//s1.average();
		student s2=new student("shyam",102,85,90);
		//s2.average();
		a.add(s1);
		a.add(s2);
	}
	public void display() {
		for(student s:a) {//it will internally create objects of student type without using new
			//s.marks_java=100;//the changes will be reflected in s object.
			
			//s.average();//the value will be stored in memory location of arrayList -s1 and s2
			System.out.println("Name:"+s.name+" Rollno:"+s.rollno+" Java:"+s.marks_java+" Sel:"+s.marks_Selenium+" Avg:"+s.avg);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList1 a1=new ArrayList1();
		a1.create();
		a1.display();
		

	}

}
