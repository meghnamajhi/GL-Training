package DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class EX_OPERATION {

		public ArrayList<STUDENT> read_excel() 
		{
			
			ArrayList<STUDENT> std_al= new ArrayList<STUDENT>();
			for(int i=1;i<=10;i++) {
				STUDENT s=new STUDENT();

			try {

				File f=new File("C:\\Training\\Book3.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r= sh.getRow(i);

				XSSFCell c=r.getCell(0);
				s.rollno=(int)c.getNumericCellValue();

				XSSFCell c1=r.getCell(1);
				s.name=c1.getStringCellValue();

				XSSFCell c2=r.getCell(2);
				s.marks_java=(int)c2.getNumericCellValue();

				XSSFCell c3=r.getCell(3);
				s.marks_Selenium=(int)c3.getNumericCellValue();
				
				System.out.println(s);
				s.average();
				//System.out.println(s.average());
				std_al.add(s);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			return std_al;
		}
		public void write_excel(ArrayList<STUDENT> s1) {
			int ri=1;
			
			try {
				File f=new File("C:\\Training\\Book3.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				for(STUDENT s:s1) {
				XSSFRow r= sh.getRow(ri);
				XSSFCell c=r.createCell(4);
				
				c.setCellValue(s.avg);
				
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
				ri++;
			}
		}
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
	


