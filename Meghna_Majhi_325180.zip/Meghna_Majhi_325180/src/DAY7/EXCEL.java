
package DAY7;

import java.util.ArrayList;

public class EXCEL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EX_OPERATION excel=new EX_OPERATION();
	
			ArrayList<STUDENT> s1=new ArrayList<STUDENT>();
			s1=excel.read_excel();
			excel.write_excel(s1);
		

	}
}