package DAY7;

public class STUDENT {


	// TODO Auto-generated method stub
	public String name;
	public int rollno;
	public int marks_java;
	public int marks_Selenium;
	public float avg;

	public float average() {
		avg=(marks_java+marks_Selenium)/2.0f;
		return avg;
	}


}
