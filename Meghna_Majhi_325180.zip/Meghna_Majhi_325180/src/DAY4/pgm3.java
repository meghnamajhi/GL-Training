package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line="I am working with global logic in noida";
		int l=line.length();
		int s1=0,s2=0,s3=0;
		while(s3!=-1){
			s2=line.indexOf(" ",s1+1);
			if(s2==-1) {
				s2=l;
				s3=-1;
			}
			
			String word=line.substring(s1,s2);
			System.out.println(word);
			s1=s2;
			
		}

	}

}
