package DAY4;
import java.util.Scanner;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner inp=new Scanner(System.in);
		int r=inp.nextInt();
		int c=inp.nextInt();
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
				System.out.println(" ");
			}
		}

	}

}
