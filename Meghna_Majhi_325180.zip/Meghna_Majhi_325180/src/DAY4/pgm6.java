package DAY4;

public class pgm6 {

		static String line="i am learning java";
		static int l=line.length();
		static int []noc=new int[100];
		static char []ch  =new char[100];
		public static int c=0;

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			for(int i=0;i<l;i++) {
				check_char(line.charAt(i));
			}
			count();
			dispay();
		}

		private static void dispay() {
			// TODO Auto-generated method stub
			for(int i=0;i<c;i++) {
				System.out.println(ch[i]+"="+noc[i]);
			}
		}

		public static void count() {
			// TODO Auto-generated method stub
			for(int n=0;n<c;n++) {
				int  counter=0;
				for(int j=0;j<l;j++) {
					if(ch[n]==line.charAt(j))
						counter++;
				}
				noc[n]=counter;
			}
		}

		public static  void check_char(char charAt) {
			// TODO Auto-generated method stub
			boolean f=true;
			for(int m=0;m<=c;m++) {
				if(charAt==ch[m]) {
					f=false;
				}
			}
			if(f==true) {
				ch[c]=charAt;
				c++;
			}
		}



	

}
