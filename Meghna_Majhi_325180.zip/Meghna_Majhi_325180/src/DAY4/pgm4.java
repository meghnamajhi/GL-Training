package DAY4;
public class pgm4 {

	
		// TODO Auto-generated method stub
		public int add(int x,int y) {
			int z=x+y;
			return z;
			
		}
		public float add(float x,float y) {
			float z=x+y;
			return z;
		}
		

	
}
