package DAY4;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int jmax=4;
		int kmax=1;
		int jma=3;
		int kma=0;
		for(int i=1;i<=3;i++) {
			for(int j=1;j<=jmax;j++) {
				System.out.print(" ");
			}
			jmax=jmax-2;
			for(int k=1;k<=kmax;k++) {
				System.out.print("1 ");
			}
			kmax++;
			for(int j=1;j<=jma;j++) {
				System.out.print(" ");

			}
			jma=jma-3;
			for(int k=1;k<=kma;k++) {
				System.out.print("1 ");
			}
			kma=kma+1;

			System.out.println();
		}
		

	}

}
