package DAY4;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm4 obj=new pgm4();
		int x= obj.add(10, 20);
		float y=obj.add(5.5f, 9.7f);
		System.out.println(x);
		System.out.println(y);

	}

}
