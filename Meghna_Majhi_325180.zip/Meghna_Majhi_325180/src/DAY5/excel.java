package DAY5;


public class excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excelOperation excel=new excelOperation();
		for(int i=1;i<=3;i++) {
			student s1=excel.read_excel(i);
			s1.average();
			excel.write_excel(s1,i);
		}
	}
}
