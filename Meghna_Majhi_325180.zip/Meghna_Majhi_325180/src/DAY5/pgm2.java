package DAY5;

public class pgm2 {
	public static void main(String[] args) {
		int n=10,m=0,p;
		
		try {
		p=n/m;
		System.out.println(p);
		int a[]= {1,2,3};
		System.out.println(a[3]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Catch");
		}
		catch(ArithmeticException e) {
			System.out.println("In catch");
		}
		catch(Exception e) {
			System.out.println("try");
		}
		
	}
}