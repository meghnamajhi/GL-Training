package DAY8;

public class Student {
	public int SLNo ;
	public String PassengerName;
	public String From;
	public String To;
	public int Rate;
	public int NoOfSeats;
	public int Total;
	
	public double totalCost() {
		Total=Rate*NoOfSeats;
		return Total;
	}
	
}
