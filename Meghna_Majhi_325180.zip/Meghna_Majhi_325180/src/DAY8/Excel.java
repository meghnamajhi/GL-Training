package DAY8;
import java.util.ArrayList;

public class Excel {
	public static void main(String main[]) {
		ExcelOperation obj=new ExcelOperation();
		ArrayList<Student> s=new ArrayList<Student>();
		s=obj.readExcel();
		obj.writeExcel(s);
		
	}

}
