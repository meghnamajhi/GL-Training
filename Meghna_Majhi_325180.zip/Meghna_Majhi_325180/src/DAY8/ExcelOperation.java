package DAY8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelOperation {
	public ArrayList<Student> readExcel(){
		ArrayList<Student> std=new ArrayList<Student>();
		for(int i=1;i<=4;i++) {
			Student s1=new Student();
			
		try {
			File f=new File("C:\\Training\\Book4.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r= sh.getRow(i);
			
			XSSFCell c=r.getCell(0);
			s1.SLNo=(int)c.getNumericCellValue();

			XSSFCell c1=r.getCell(1);
			s1.PassengerName=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			s1.From=c2.getStringCellValue();

			XSSFCell c3=r.getCell(3);
			s1.To=c3.getStringCellValue();
			
			XSSFCell c4=r.getCell(4);
			s1.Rate=(int)c4.getNumericCellValue();

			XSSFCell c5=r.getCell(5);
			s1.NoOfSeats=(int)c5.getNumericCellValue();
			
			System.out.println(s1);
			s1.totalCost();
			//System.out.println(s.average());
			std.add(s1);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
		return std;
		}
	public void writeExcel(ArrayList<Student> s) {
		int ri=1;
		
		try {
			File f=new File("C:\\Training\\Book4.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(Student s1:s) {
			XSSFRow r= sh.getRow(ri);
			XSSFCell c=r.createCell(6);
			
			c.setCellValue(s1.Total);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			ri++;
		}
	}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

		
	


