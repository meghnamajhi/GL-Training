package DAY9;

public class icici extends bank{
	public float getRoi() {
		return 8.5f;
	}

}
