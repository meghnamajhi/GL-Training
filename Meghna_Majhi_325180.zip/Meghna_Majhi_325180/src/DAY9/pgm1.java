package DAY9;

public class pgm1 {
	private int AccountNo;
	private int AccountBal;
	
	public int getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}
	public int getAccountBal() {
		return AccountBal;
	}
	public void setAccountBal(int accountBal) {
		AccountBal = accountBal;
	}	
}
