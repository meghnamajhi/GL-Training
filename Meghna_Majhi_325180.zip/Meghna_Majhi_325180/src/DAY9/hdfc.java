package DAY9;

public class hdfc extends bank {
	public float getRoi() {
		return 7.5f;
	}

}
