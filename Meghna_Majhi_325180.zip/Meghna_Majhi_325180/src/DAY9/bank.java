package DAY9;

public class bank {
	public float getRoi() {
		return 0f;
	}
	public void show() {
		System.out.println("Bank Details");
	}

}
