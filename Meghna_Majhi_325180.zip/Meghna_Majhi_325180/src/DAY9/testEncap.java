package DAY9;

public class testEncap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm1 e = new pgm1();
		e.setAccountNo(1001);
		e.setAccountBal(12345);
		System.out.println("Account No: "+e.getAccountNo()+" Account Balance: "+e.getAccountBal());

	}

}
