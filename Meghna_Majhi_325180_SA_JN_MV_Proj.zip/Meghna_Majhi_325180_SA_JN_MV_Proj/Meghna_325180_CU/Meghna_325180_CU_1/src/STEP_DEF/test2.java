package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	WebDriver dr;
	@When("^User enters invalid login details$")
	public void user_enters_invalid_login_details() throws Throwable {
		dr=test1.dr;
		System.out.println("User enters invalid login details");

		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("m1eghnamajhi123@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("30041997");

		dr.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"))
				.click();
	}
	@Then("^Home page is not displayed$")
	public void home_page_is_not_displayed() throws Throwable {
	    System.out.println("Home page is not displayed");
	}

}
