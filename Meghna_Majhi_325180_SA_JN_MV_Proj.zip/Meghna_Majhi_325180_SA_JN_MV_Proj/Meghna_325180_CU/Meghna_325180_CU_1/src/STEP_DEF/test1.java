package STEP_DEF;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

//step definition file

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	public static WebDriver dr;

	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {

		System.out.println("Login page is displayed");
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();

	}

	@When("^User enters login details$")
	public void user_enters_login_details() throws Throwable {
		System.out.println("User enters login details");

		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("meghnamajhi@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("30041997");

		dr.findElement(
				By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"))
				.click();
	}

	/*
	 * @When("^User enters invalid login details$") public void
	 * user_enters_invalid_login_details() throws Throwable {
	 * System.out.println("User enters invalid login details");
	 * 
	 * dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(
	 * "meghnamajhi123@gmail.com");
	 * dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("30041997");
	 * 
	 * dr.findElement( By.xpath(
	 * "/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"
	 * )) .click(); }
	 */

	/*
	 * @Then("^Home page is displayed$") public void home_page_is_displayed() throws
	 * Throwable { System.out.println("Home page is displayed"); String er =
	 * "meghnamajhi1@gmail.com"; String ar = dr.findElement(By.xpath(
	 * "/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	 * SoftAssert sa = new SoftAssert(); sa.assertEquals(ar, er);
	 * System.out.println("Actual Result :  " + ar + ", Expected Result :  " + er);
	 * sa.assertAll(); dr.findElement(By.xpath(
	 * "/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	 * dr.close(); }
	 */

	/*
	 * @Then("^Home page is not displayed$") public void
	 * home_page_is_not_displayed() throws Throwable {
	 * System.out.println("Home page is not displayed");
	 * 
	 * String er="meghnamajhi@gmail.com"; String ar=dr.findElement(By.xpath(
	 * "/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	 * SoftAssert sa=new SoftAssert(); sa.assertEquals(ar,er);
	 * System.out.println("Actual Result :  "+ar+ ", Expected Result :  "+er );
	 * sa.assertAll();
	 * 
	 * }
	 */

}
