package TEST_RUNNER;

//import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;   

import cucumber.api.testng.AbstractTestNGCucumberTests;
//STEP_DEF is name of package which contain webdriver code
@CucumberOptions(features="FEATURES",tags="@ROUND2",glue="STEP_DEF",
					plugin="html:reports/cucumber-report")
//name of folder which contains feature file
public class testrunner extends AbstractTestNGCucumberTests{
	

}
