$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT  login",
  "description": "",
  "id": "aut--login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 9,
  "name": "To verify login for invalid data",
  "description": "",
  "id": "aut--login;to-verify-login-for-invalid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 8,
      "name": "@ROUND2"
    }
  ]
});
formatter.step({
  "line": 10,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "User enters invalid login details",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "Home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 6749126900,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_invalid_login_details()"
});
formatter.result({
  "duration": 1519771900,
  "status": "passed"
});
formatter.match({
  "location": "test2.home_page_is_not_displayed()"
});
formatter.result({
  "duration": 45700,
  "status": "passed"
});
});