$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT  login",
  "description": "",
  "id": "aut--login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "To verify login for valid data",
  "description": "",
  "id": "aut--login;to-verify-login-for-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters login detail",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "verify projectName",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "verify startDate",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "verify endDate",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "verify customerName",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "verify businessUnit",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "verify shadowAllocationAllowed",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "verify allocationsforMonth",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "second page",
  "keyword": "And "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 8894105000,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_details()"
});
formatter.result({
  "duration": 622568900,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 1802057400,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyprojectName()"
});
formatter.result({
  "duration": 1153534300,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyStartDate()"
});
formatter.result({
  "duration": 45437600,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyEndDate()"
});
formatter.result({
  "duration": 42803000,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyCustomerName()"
});
formatter.result({
  "duration": 111058900,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyBusinessUnit()"
});
formatter.result({
  "duration": 41196300,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyShadowAllocationAllowed()"
});
formatter.result({
  "duration": 45702600,
  "status": "passed"
});
formatter.match({
  "location": "test1.verifyAllocationsforMonth()"
});
formatter.result({
  "duration": 4575012700,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 17,
  "name": "To verify system behaviour",
  "description": "",
  "id": "aut--login;to-verify-system-behaviour",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "User enters login detail",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "Home page",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 9004136300,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_details()"
});
formatter.result({
  "duration": 538348000,
  "status": "passed"
});
formatter.match({
  "location": "test2.home_page_is_display()"
});
formatter.result({
  "duration": 759837800,
  "status": "passed"
});
});