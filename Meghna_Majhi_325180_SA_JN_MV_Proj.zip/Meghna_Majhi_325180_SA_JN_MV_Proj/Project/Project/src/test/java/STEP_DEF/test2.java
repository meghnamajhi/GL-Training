package STEP_DEF;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Then;


public class test2 {
	WebDriver dr;
	@Then("^Home page$")
	public void home_page_is_display() throws Throwable {
		System.out.println("B");
		dr=test1.dr;

		dr.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		WebElement we1=dr.findElement(By.xpath("//*[@id=\"ramenu\"]/li[2]/a"));
		Actions kb=new Actions(dr);
		kb.moveToElement(we1).build().perform();
		System.out.println("A");
		//WebElement we2=dr.findElement(By.xpath("//*[@id=\"ramenu\"]/li[2]/ul/li[1]/a"));
	}	
	
}
