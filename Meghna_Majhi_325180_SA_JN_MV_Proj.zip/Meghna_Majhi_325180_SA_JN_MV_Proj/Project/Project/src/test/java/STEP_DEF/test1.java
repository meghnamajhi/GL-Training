package STEP_DEF;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	public static WebDriver dr;

	WebDriverWait drw;
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
		
		  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe"); 
		  dr =new ChromeDriver();
		 
		dr.get("https://ra-staging.globallogic.com/login");
		System.out.println("Login page is displayed 1");
	
	}

	@When("^User enters login detail$")
	public void user_enters_login_details() throws Throwable {
		System.out.println("User enters login details 1");

		drw=new WebDriverWait(dr,20);
		drw.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/user-app/ng-component/div[2]/form/div[5]/div/input")));
		dr.findElement(By.xpath("/html/body/user-app/ng-component/div[2]/form/div[5]/div/input")).sendKeys("meghna.majhi");
		dr.findElement(By.xpath("/html/body/user-app/ng-component/div[2]/form/div[6]/div/input")).sendKeys("30041997Megh#");
		dr.findElement(By.xpath("/html/body/user-app/ng-component/div[2]/form/input")).click();
	}
	
	//@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {

		dr.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		WebElement we1=dr.findElement(By.xpath("//*[@id=\"ramenu\"]/li[2]/a"));
		Actions kb=new Actions(dr);
		kb.moveToElement(we1).build().perform();
		WebElement we2=dr.findElement(By.xpath("//*[@id=\"ramenu\"]/li[2]/ul/li[1]/a"));
		Actions kb1=new Actions(dr);
		kb1.moveToElement(we2).build().perform();
		
		dr.findElement(By.xpath("//*[@id=\"ramenu\"]/li[2]/ul/li[1]/ul/li[1]/a")).click();		
		dr.findElement(By.xpath("//*[@id=\"mysearch\"]")).sendKeys("LogRhythm");
		dr.findElement(By.xpath("//*[@id=\"imaginary_container\"]/div/type-ahead/typeahead-container/ul/li[1]/a")).click();
		 
		System.out.println("Home page is displayed");		
	}
	@Then("^verify projectName$")
	public void verifyprojectName() throws Throwable {
		String projectName="Project Type: Time and Material";
		String projectName1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[1]")).getText(); 
		 //System.out.println(projectName1);	
		 
		 SoftAssert sa1=new SoftAssert(); 
		 sa1.assertEquals(projectName,projectName1);
		 sa1.assertAll();
		
	}
	@Then("^verify startDate$")
	public void verifyStartDate() throws Throwable {
		String startDate="Start Date: 2012-11-05";
		String startDate1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[2]")).getText();
		 //System.out.println(startDate1);
		 
		 SoftAssert sa2=new SoftAssert(); 
		 sa2.assertEquals(startDate,startDate1);
		 sa2.assertAll();
		
	}
	@Then("^verify endDate$")
	public void verifyEndDate() throws Throwable {
		String endDate="End Date: 2020-06-28";
		String endDate1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[3]")).getText(); 
		//System.out.println(endDate1);
		 
		SoftAssert sa3=new SoftAssert(); 
		 sa3.assertEquals(endDate,endDate1);
		 sa3.assertAll();
		
	}
	@Then("^verify customerName$")
	public void verifyCustomerName() throws Throwable {
		String customerName="Customer Name: LogRhythm";
		String customerName1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[4]")).getText(); 
		//System.out.println(customerName1);
		 
		SoftAssert sa4=new SoftAssert(); 
		sa4.assertEquals(customerName,customerName1);
		sa4.assertAll();
	}
	@Then("^verify businessUnit$")
	public void verifyBusinessUnit() throws Throwable {
		String businessUnit="Business Unit: Technology";
		String businessUnit1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[5]")).getText(); 
		//System.out.println(businessUnit1);
		 
		SoftAssert sa5=new SoftAssert(); 
		sa5.assertEquals(businessUnit,businessUnit1);
		sa5.assertAll();
		
	}
	@Then("^verify shadowAllocationAllowed$")
	public void verifyShadowAllocationAllowed() throws Throwable {
		String shadowAllocationAllowed="Shadow Allocation Allowed: No";
		String shadowAllocationAllowed1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[6]")).getText(); 
		//System.out.println(shadowAllocationAllowed1);
		 
		SoftAssert sa6=new SoftAssert(); 
		sa6.assertEquals(shadowAllocationAllowed,shadowAllocationAllowed1);
		sa6.assertAll();
		
	}
	@Then("^verify allocationsforMonth$")
	public void verifyAllocationsforMonth() throws Throwable {
		String allocationsforMonth="Nov, 2019";
		dr.manage().window().maximize();
		  dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[7]/span/fdms-month-picker/div/span")).click();
		  try {
			  Thread.sleep(3000);
		  }
		  catch(Exception e)
		  {}
		  String allocationsforMonth1=dr.findElement(By.xpath("//*[@id=\"tabA\"]/div/form/div/div[2]/div/div[1]/div[1]/div/div[2]/div/p[7]/span/fdms-month-picker/div/div/div[1]")).getText();
		  //System.out.println(s);
		
		SoftAssert sa7=new SoftAssert(); 
		sa7.assertEquals(allocationsforMonth,allocationsforMonth1);
		sa7.assertAll();
		
	}
	/*
	 * @Then("^second page$") public void second_page() throws Throwable { // Write
	 * code here that turns the phrase above into concrete actions
	 * System.out.println("in b"); }
	 */
	
	@Then("^second page$")
	public void second_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("second page");
	}
	
	@Then("^page1$")
	public void page1() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("page1");
	}
	
	@Then("^page2$")
	public void page2() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("page2");
	}
	
	
}

