package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="ZAUT",glue="STEP_DEF",
						plugin="html:reports/cucumber-report")
	//name of folder which contains feature file
	public class testrunner extends AbstractTestNGCucumberTests{
		
	
}

