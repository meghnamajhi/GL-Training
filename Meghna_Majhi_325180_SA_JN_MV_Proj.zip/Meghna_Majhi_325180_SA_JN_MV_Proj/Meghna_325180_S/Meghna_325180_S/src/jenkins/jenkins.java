package jenkins;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class jenkins {
	public static void main(String args[]) {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		driver= new ChromeDriver();
		System.out.println("abc");
		driver.get("https://www.facebook.com");
	}
}
