package HFW;

import java.io.IOException;

import org.apache.log4j.Logger;

public class HFW extends excel_read{
	static Logger log;
	static keyword_sh d=new keyword_sh();
	static tc_selection td =new tc_selection();
	static String filename="";
	public static void main(String a[])throws IOException{

		String id,ch,testdata=null;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
			td=read_Sheet1(i);
			System.out.println(td.flag);
			if(td.flag.equals("Y")) {
				for(j=1;j<20;j++) {
					d=excel_read.read_kw_sh(j);
					System.out.println("d.TC_ID: "+d.TC_ID);
					if(d.TC_ID.equals(td.tcid)) {
						System.out.println("Yes");
						break;
					}
					else {
						continue;
					}
					get_test_data(td.test_data_sh,2,2);
					display_testdata();

					for(login_test_data data:td_al) {
						for(k=j;k<=((j+td.no_steps)-1);k++) {
							if(k==(j+2)) {
								testdata=data.uid;
							}
							if(k==(j+3)) {
								testdata=data.pwd;
							}
							d=excel_read.read_kw_sh(k);
							ch=d.Keyword;
							System.out.println("testdata: "+testdata);
							switch(ch) {
							case "launchBrowser":
								all_methods.LaunchBrowser(d.XPath);
								break;
							case "enterText":
								all_methods.enter_text(d.XPath,testdata);
								break;
							case "clickButton":
								all_methods.clickButton(d.XPath);
								break;
							case "clickLink":
								all_methods.clickButton(d.XPath);
								break;
							case "clickRadioButton":
								all_methods.R_SEX(D.Test_Data);
								break;
							case "verify":
								excel_write.write_sheet2(k,all_methods.verofy(d.XPath,d.TestData));
								System.out.println(k+" "+all+methods.verify(d.XPath,d.Test_Data));
								break;
							}
						}
					}
					if(k==(j+td.no_steps)) {
						System.out.println(i+"pass");
					}
					else {
						System.out.println("fail");
						excel_write.write_sheet1(i,"fail");
					}
				}
			}
		
		}
		
		
		
		
	}

}
