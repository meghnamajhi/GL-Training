package WEEKEND2;

import java.util.ArrayList;
public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<product> al = new ArrayList<product>();
		operations op1 = new operations();
		
		
		al=op1.read_excel();
		
		op1.write_excel(al);

	}

}
