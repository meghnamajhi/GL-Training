package WEEKEND2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student(1,"A",99,83);
		student s2=new student(2,"B",88,69);
		student s3=new student(3,"C",90,72);
		s1.avg();
		s2.avg();
		s3.avg();
		if(s1.avg>65) {
		  System.out.println("Name: " + s1.name + "RollNo: " + s1.rollno + "JavaMarks: " + s1.java + "SeleniumMarks: "+ s1.selenium );
		}
		if(s2.avg>65) {
		System.out.println("Name: " + s2.name + "RollNo: " + s2.rollno + "JavaMarks: " + s2.java + "SeleniumMarks: "+ s2.selenium );
		}
		if(s3.avg>65) {
		System.out.println("Name: " + s3.name + "Roll No: " + s3.rollno + "JavaMarks: " + s3.java + "SeleniumMarks: "+ s3.selenium );	
		}		
	}
}
