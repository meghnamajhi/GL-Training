package WEEKEND2;

public class pgm3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={23,44,84,37,91,18};
		int sum=0;
		for(int i=1;i<6;i=i+2) {
			if(a[i]%2!=0) {
				sum=sum+a[i];
			}
		}
		System.out.println(sum);
	}
}
