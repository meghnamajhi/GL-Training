package WEEKEND2;

public class pgm5 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			PARROTS p1 = new PARROTS(51,40,8,"pink","fruits","F","kakapo",2);
			PARROTS p2 = new PARROTS(60,40,4,"Red","seeds","M","Macaw",2);
			PARROTS p3 = new PARROTS(8,11,2,"Blue","insects","F","Pygmy",2);
			OWLS o1 = new OWLS(4,62,3,"Black","squirrel","F","Barn",2);
			OWLS o2= new OWLS(7,20,4,"Grey","insect","M","Eurasian",2);
			
			p1.display();
			p1.eats();
			p1.flys();
			p2.display();
			p2.copy();
			p2.flys();
			p3.display();
			p3.eats();
			p3.found();		
			o1.display();
			o1.eats();
			o1.rotate_neck();
			o2.display();
			o2.hunts();
			
		}
}
