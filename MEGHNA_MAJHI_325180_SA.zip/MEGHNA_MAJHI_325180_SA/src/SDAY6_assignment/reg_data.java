package SDAY6_assignment;

public class reg_data {
	public String gender,F_Name,L_Name,mail_id,pwd,con_pwd;
	
	public void display() {
		System.out.println("gender: "+this.gender
				+"\n F_Name: "+this.F_Name
				+"\n L_Name: "+this.L_Name
				+"\n mail_id: "+this.mail_id
				+"\n pwd: "+this.pwd
				+"\n con_pwd: "+this.con_pwd
				);
	}

}
