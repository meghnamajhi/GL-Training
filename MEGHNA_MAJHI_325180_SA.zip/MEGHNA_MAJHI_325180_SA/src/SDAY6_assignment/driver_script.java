package SDAY6_assignment;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,loc,td;
		WebDriver dr=null;
		webelement we=new webelement(dr);
		excel_operation excel=new excel_operation();
		for(int r=0;r<=16;r++) {
			kw=excel.read_excel(r,1);
			loc=excel.read_excel(r,2);
			td=excel.read_excel(r,3);
			switch(kw) {
			case "launchchrome" :
				we.launchChrome(td);
				break;
				
			case "enter_text" :
				we.enter_text(loc,td);
				break;
				
			case "click_btn" :
				we.click(loc);
				break;
				
			case "choose_gender" :
				we.chooseGender(loc);
				break;
			case "verify" :
				String a=we.verify(loc,td);
				excel.write_excel(r,a);
				break;
			case "close" :
				we.close();
				break;
			}
		}

	}

}
