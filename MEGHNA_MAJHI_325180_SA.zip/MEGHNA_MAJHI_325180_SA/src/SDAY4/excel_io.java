package SDAY4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class excel_io {
	static ArrayList<login_data> data_al;
	public static void get_test_data() {

		//String s=null;
		try {

			File f=new File("C:\\Training\\login.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(int r1=1;r1<=2;r1++) {
				login_data td=new login_data();
				XSSFRow r=sh.getRow(r1);

				XSSFCell c=r.getCell(0);
				td.uid=c.getStringCellValue();

				XSSFCell c1=r.getCell(1);
				td.pwd=(int)c1.getNumericCellValue();

				XSSFCell c2=r.getCell(2);
				td.exp_res1=c2.getStringCellValue();

				if(td.exp_res1=="FAILURE") {
				XSSFCell c3=r.getCell(3);
				td.exp_em1=c3.getStringCellValue();

				XSSFCell c4=r.getCell(4);
				td.exp_em2=c4.getStringCellValue();
				}

				data_al.add(td);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public static void write_excel(int r, login_data ld2) {
		File f=new File("C:\\Training\\login.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.createCell(5);
			cell.setCellValue(ld2.act_res1);
			if(ld2.act_res1.equals("FAILURE")) {
				XSSFCell cell2=row.createCell(6);
				cell2.setCellValue(ld2.act_em1);

				XSSFCell cell3=row.createCell(7);
				cell3.setCellValue(ld2.act_em2);
				
				XSSFCell cell4=row.createCell(8);
				cell4.setCellValue(ld2.test_res1);
			}
			else if(ld2.act_res1.equals("SUCCESS")) {
				XSSFCell cell4=row.createCell(8);
				cell4.setCellValue(ld2.test_res1);
			}

			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
