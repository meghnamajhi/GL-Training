package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class aut_login {
	public static login_data a=new login_data();
	
	public static login_data read_data() {
		//login_data a=new login_data();
		try {
			File f=new File("D:\\Softwares\\selenium\\Book2.xlsx");
			FileInputStream fis;
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
				XSSFRow r= sh.getRow(1);
				
				XSSFCell c1=r.getCell(0);
				a.uid=c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(1);
				a.pwd=(int)c2.getNumericCellValue();
				
				XSSFCell c3=r.getCell(2);
				a.exp=c3.getStringCellValue();
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	public static void write_data() {
		
		try {
			File f=new File("D:\\Softwares\\selenium\\Book2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.createCell(3);
			c.setCellValue(a.act);
			XSSFCell c1=r.createCell(4);
			if((a.act).equals(a.exp)) {
				a.test="success";
			}
			else {
				a.test="fail";
			}
			c1.setCellValue(a.test);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
			
	public static void login() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		dr.findElement(By.name("Email")).sendKeys(a.uid);
		String s=Integer.toString(a.pwd);
		dr.findElement(By.name("Password")).sendKeys(s);
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		if(s1.equals("meghnamajhi@gmail.com")) {
			System.out.println("Successful");
			a.act="Success";
		}
		
		else {
			System.out.println("UnSuccessful");
			a.act="fail";
		}
	
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		a=read_data();
		login();
		write_data();
		

	}

}
