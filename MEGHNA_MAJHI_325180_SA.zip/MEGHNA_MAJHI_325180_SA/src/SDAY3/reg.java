package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class reg {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");

		String title=dr.getTitle();
		System.out.println("Title: "+title);
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
		dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Meghna");
		dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("Majhi");
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("trylyff1@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("30041997");
		dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("30041997");
		dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
		if(s.equals("Your registration completed")) {
			System.out.println("Successful");
		}
		else {
			System.out.println("UnSuccessful");
		}
	
	String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	if(s1.equals("trylyff@gmail.com")) {
		System.out.println("Showing email id on top");
	}
	else {
		System.out.println("Not showing email id");
	}
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	dr.close();
	}
}
