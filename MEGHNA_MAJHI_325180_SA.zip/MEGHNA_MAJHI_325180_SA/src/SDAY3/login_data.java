package SDAY3;

public class login_data {
	String uid,exp,act,test;
	int pwd;
	

}
