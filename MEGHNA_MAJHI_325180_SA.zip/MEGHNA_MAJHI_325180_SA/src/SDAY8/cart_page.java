package SDAY8;

import org.openqa.selenium.WebDriver;

public class cart_page {
	WebDriver dr;
	public cart_page(WebDriver dr) {
		this.dr=dr;
	}
	//hp.add_to_cart(1);
	public void add_to_cart(int i) {
		// TODO Auto-generated method stub
		System.out.println(i);
	}

}
