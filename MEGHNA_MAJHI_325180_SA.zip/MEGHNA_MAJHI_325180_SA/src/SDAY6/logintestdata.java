package SDAY6;

public class logintestdata {
	String uid, pwd;
	
	logintestdata(String uid, String pwd)
	{
		this.uid=uid;
		this.pwd=pwd;
	}

}
