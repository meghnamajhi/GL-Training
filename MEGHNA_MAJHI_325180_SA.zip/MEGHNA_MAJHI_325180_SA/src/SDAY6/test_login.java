package SDAY6;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login extends excel_io {
	
	public static void login(login_data Ldata) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(Ldata.uid);
		String s=Integer.toString(Ldata.pwd);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(s);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		boolean f=dr.getTitle().contains("Login");
		
		if(!f) {
			Ldata.act_res1="SUCCESS";
			System.out.println("Login Successful");
		}
		else {
			Ldata.act_res1="FAILURE";
			Ldata.act_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			Ldata.act_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		}
		if(Ldata.exp_res1.equals("FAILURE")) {
			System.out.println("Ldata.exp_em1: "+Ldata.exp_em1+"Ldata.exp_em2: "+Ldata.exp_em2+"Ldata.act_em1"+Ldata.act_em1 +"Ldata.act_em2"+Ldata.act_em2);
			if(Ldata.exp_em1.equals(Ldata.act_em1)&&Ldata.exp_em2.equals(Ldata.act_em2)) {
				Ldata.test_res1="PASS";
			}
			else {
				Ldata.test_res1="FAIL";
			}
		}
		else {
			Ldata.test_res1="PASS";
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			dr.close();
		}
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0,row=1;
		
		data_al=new ArrayList<login_data>();		
		get_test_data();
		
		for(login_data ld:data_al) {			
			login(ld);
			//ld.display();
			write_excel(row,ld);
			row++;			
		}		
		/*
		 * for(login_data ld:data_al) { //login_data ld1=login(ld);
		 * //data_al.set(c,ld1); ld.display(); write_excel(row,ld1); c++; row++;
		 * 
		 * }
		 */
	}
}
