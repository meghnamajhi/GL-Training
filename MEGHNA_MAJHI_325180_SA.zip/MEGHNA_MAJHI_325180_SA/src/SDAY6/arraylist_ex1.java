package SDAY6;

import java.util.ArrayList;

public class arraylist_ex1 {

	static ArrayList<logintestdata> data_al;
	
	public static void display()
	{
		for(logintestdata ld : data_al)
		{
			System.out.println("ld.uid : " + ld.uid + " ld.pwd : " + ld.pwd);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		data_al = new ArrayList<logintestdata>();
		
		logintestdata ld1 = new logintestdata("uid1","pwd1");
		logintestdata ld2 = new logintestdata("uid2","pwd2");
		
		data_al.add(ld1);
		data_al.add(ld2);
	
		display();
 
	}

}
