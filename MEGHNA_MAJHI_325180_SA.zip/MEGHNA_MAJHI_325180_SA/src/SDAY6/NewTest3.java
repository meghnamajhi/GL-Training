package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY4.login_data;
import SDAY4.test_login;

public class NewTest3 {
	test_login loginobj;
	login_data ldata,ldata_out;
	
	@Test
	public void t1() {
		ldata=new login_data();
		ldata_out=new login_data();
		loginobj= new test_login();
		
		ldata.uid="meghnamajhi@gmail.com";
		ldata.pwd=30041997;
		ldata.exp_res1="SUCCESS";
		
		ldata_out=loginobj.login(ldata);
		System.out.println("ldata_out.act_res1"+ldata_out.act_res1);
		
	}
	@Test
	public void t2() {
		ldata=new login_data();
		ldata_out=new login_data();
		loginobj= new test_login();
		
		ldata.uid="meghnamajhi@gmail.com";
		ldata.pwd=30041996;
		ldata.exp_res1="SUCCESS";
		ldata.exp_em1="Login was unsuccessful.Please correct the errors and try again";
		ldata.exp_em2="The credentials proovided are incorrect";
		
		ldata_out=loginobj.login(ldata);
		
		SoftAssert sa= new SoftAssert();
		sa.assertEquals(ldata_out.act_res1,ldata_out.exp_res1);
		//System.out.println("In test b");
		
		System.out.println("ldata_out.act_res1"+ldata_out.act_res1);
		sa.assertAll();
	}

}
