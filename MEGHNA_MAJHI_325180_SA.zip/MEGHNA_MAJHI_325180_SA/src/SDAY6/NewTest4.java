package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY4.login_data;
import SDAY4.test_login;

public class NewTest4 {   

	test_login loginob;
	login_data ldata,ldata_out;
	@BeforeClass
	public void config() {
		ldata=new login_data();
		ldata_out=new login_data();
		loginob=new test_login();
	}
	@Test(dataProvider="security")
	public void login_test1(String u, int p, String exp_res) {
		System.out.println("Login: "+u+" "+p);
		ldata.uid=u;
		ldata.pwd=p;
		String s=Integer.toString(ldata.pwd);
		ldata.exp_res1=exp_res;
		ldata_out=loginob.login(ldata);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(ldata_out.act_res1, ldata_out.exp_res1);
		sa.assertAll();
	}

	@DataProvider(name="security")
	public String[][] getdata(){
		String [][]data= {{"meghnamajhi@gmail.com","30041997","SUCCESS"},{"meghnamajhi@gmail.com","hgchchc","FAILURE"}};
		return data;
	}
}
