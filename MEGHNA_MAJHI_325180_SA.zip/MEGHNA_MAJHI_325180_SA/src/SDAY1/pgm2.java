package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		dr.findElement(By.name("email")).sendKeys("8961214175");
		dr.findElement(By.name("pass")).sendKeys("20032001");
		
		//dr.findElement(By.name("login")).click();
		//dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[2]/button")).click();
		dr.findElement(By.xpath("//*[@id=\"u_0_2\"]")).click();
		
		String a= dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
		if(a.equals("Meghna")) {
			System.out.println("Successful");
		}
		else {
			System.out.println("unSuccessful");
		}
		
		
		String title=dr.getTitle();
		System.out.println("Title: "+title);
		
		List rb=dr.findElements(By.name("sex"));
		((WebElement) rb.get(1)).click();
		
		WebElement we=dr.findElement(By.id("day"));
		Select sell=new Select(we);
		sell.selectByVisibleText("10");
		
		WebElement we1=dr.findElement(By.id("month"));
		Select sell2=new Select(we1);
		sell2.selectByVisibleText("Jan");
		
		
		 WebElement we2=dr.findElement(By.id("year")); 
		 Select sell3=new Select(we2);
		 sell3.selectByVisibleText("1997");
		

	}
	

}
