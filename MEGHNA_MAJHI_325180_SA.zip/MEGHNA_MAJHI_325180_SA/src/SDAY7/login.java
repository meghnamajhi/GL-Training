package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
	WebDriver dr;

	public String login(String s1,String s2){
		System.setProperty("webdriver.chrome.driver", "chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();

		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(s1);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(s2);

		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

		String ar = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();

		//dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();

		dr.close();
		return ar;

	}
}