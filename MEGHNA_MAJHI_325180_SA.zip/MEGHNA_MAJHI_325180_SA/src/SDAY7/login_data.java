package SDAY7;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class login_data {

	login mc;
	String ar,er;

	@BeforeClass
	public void BC() {
		mc=new login();	
	}

	@Test(dataProvider="security")
	public void test1(String r[][]){
		String s1,s2,s3;
		for(int i=1;i<3;i++) {
			
			s1=r[i][0];
			s2=r[i][1];
			s3=r[i][2];

		er=s3;
		ar = mc.login(s1, s2);  

		SoftAssert sa=new SoftAssert();
		sa.assertEquals(ar, er);
		System.out.println("Actual Result :  "+ar+ ", Expected Result :  "+er );
		sa.assertAll();
	}
}

	@DataProvider(name="security")
	public String[][] provide_data() {
		String r[][]=null;
		//int i=1;
		
			try {
				File f=new File("C:\\Training\\login.xlsx");
				FileInputStream fis;
				fis = new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				for(int i=1;i<3;i++) {
					XSSFRow ri= sh.getRow(i);
					
					XSSFCell c1=ri.getCell(0);
					r[i][0]=c1.getStringCellValue();
					XSSFCell c2=ri.getCell(1);
					r[i][1]=c2.getStringCellValue();
					XSSFCell c3=ri.getCell(2);
					r[i][2]=c3.getStringCellValue();
				//	i++;

			} 
			}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return r;				
				
		}
		
	}
