package SDAY2;

import java.util.ArrayList;

public class excel_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excel_operation ex=new excel_operation();
		ArrayList<excel_data> a=new  ArrayList<excel_data>();
		a=ex.readex();
		System.out.println("in main"+a);
		ex.writeex(a);

	}

}
