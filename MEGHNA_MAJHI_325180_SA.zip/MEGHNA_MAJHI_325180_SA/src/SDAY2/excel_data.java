package SDAY2;

public class excel_data {
	int phy;
	int chem;
	int average;
	String name;
	
	public void avg() {
		this.average=(this.phy+this.chem)/2;
	}

}
