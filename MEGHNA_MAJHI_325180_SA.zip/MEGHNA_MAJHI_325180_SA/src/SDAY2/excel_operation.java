package SDAY2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operation {
	public ArrayList<excel_data> readex() {
		ArrayList<excel_data> arr=new ArrayList<excel_data>();
		try {
			
			File f=new File("D:\\Softwares\\selenium\\Book1.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(int i=1;i<=3;i++) {
				excel_data e=new excel_data();
				XSSFRow r= sh.getRow(i);
				
				XSSFCell c1=r.getCell(0);
				e.name=c1.getStringCellValue();

				XSSFCell c=r.getCell(1);
				e.phy=(int)c.getNumericCellValue();

				XSSFCell c2=r.getCell(2);
				e.chem=(int)c2.getNumericCellValue();
				
				e.avg();
				System.out.println(e.phy);
				System.out.println(e.chem);
				System.out.println(e.average);
				arr.add(e);
			}
			
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("in readex"+arr);
		return arr;

	}
	public void writeex(ArrayList<excel_data> exe) {
		int ri=1;
			try {
				File f=new File("D:\\Softwares\\selenium\\Book1.xlsx");
				FileInputStream fis;
				fis = new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet2");
				for(excel_data s:exe) {
					XSSFRow r= sh.getRow(ri);
					XSSFCell c=r.createCell(1);
					
					c.setCellValue(s.average);
					System.out.println("in_write"+s.average);
					FileOutputStream fos=new FileOutputStream(f);
					wb.write(fos);
					//System.out.println(s.average);
					ri++;
					
				}
					
				
					
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
}

