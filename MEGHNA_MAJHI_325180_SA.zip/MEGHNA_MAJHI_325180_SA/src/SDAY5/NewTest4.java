package SDAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	@BeforeClass
	public void BC() {
		System.out.println("I case to the cricket Stadium");
	}
	@BeforeMethod
	public void BM() {
		System.out.println("Hello");
	}
	@AfterMethod
	public void AM() {
		System.out.println("Bye");
	}
	@Test
	public void a() {
		System.out.println("I met Mr. Dhoni");
	}
	@Test
	public void b() {
		System.out.println("I had my lunch with Mr. Virat Kohli");
	}
	@Test
	public void c() {
		System.out.println("I had my lunch with Mr. Rohit Sharma");
	}
	@AfterClass
	public void AC() {
		System.out.println("Now I am back home");
	}
	

}
