package SDAY5;

public class login_data {
	public String uid,exp_res1,act_res1,test_res1;
	public String exp_em1,exp_em2,act_em1,act_em2;
	public int pwd;
	
	/*
	 * public login_data(String uid,String pwd,String exp_res,String act_res,String
	 * test_res) { this.uid=uid; this.pwd=pwd; this.exp_res1=exp_res;
	 * this.act_res1=act_res; this.test_res1=test_res; }
	 */
	
	public void display() {
		System.out.println("UID: "+this.uid
				+"\n PWD: "+this.pwd
				+"\n Exp_Res: "+this.exp_res1
				+"\n Act_Res: "+this.act_res1
				+"\n Test_Res: "+this.test_res1
				+"\n Exp_Em1: "+this.exp_em1
				+"\n Exp_Em2: "+this.exp_em2
				+"\n Act_Em1: "+this.act_em1
				+"\n Act_Em2: "+this.act_em2);
	}

}
