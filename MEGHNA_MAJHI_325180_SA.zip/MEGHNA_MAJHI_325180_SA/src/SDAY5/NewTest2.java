package SDAY5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest2 {


	public class NewTest {//in testNG class there's no main method but it still works!
		//we don't create object of class
		//not calling function....testNG takes care of all these!
	  @Test
	  public void a() {
		  System.out.println("In test1");//inside method, code will be executed sequentially
	  }
	  @AfterMethod
	  public void AM() {//for every method it will be executed!
		  System.out.println("AM");
	  }
	  @BeforeMethod
	  public void BM() {//for every method it will be executed!
		  System.out.println("BM");
	  }
	  @Test
	  public void b() {//normal methods(without @test) are just ignored if its not called by any other method
		  System.out.println("In test2");//methods are being called alphabetically
	  }
	}

}
