package GRID;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GRID_HUB_2 {
	WebDriver dr;
	String autURL, nodeURL;
	
	@Test
	public void test1() throws MalformedURLException{
		System.out.println("test1 - start");
		autURL="https://www.facebook.com";
		nodeURL="http://172.16.29.137:5566/wd/hub";
		DesiredCapabilities cap=DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		//System.setProperty("webdriver.gecko.driver","geckodriver.exe");
		dr=new RemoteWebDriver(new URL(nodeURL),cap);
		dr.get("https://www.facebook.com");
		System.out.println("test1 - stop");
	}
	@Test
	public void test2() {
		System.out.println("test2 - start");
		autURL="https://www.facebook.com";
		nodeURL="http://172.16.29.102:5566/wd/hub";
		DesiredCapabilities cap=DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		//System.setProperty("webdriver.gecko.driver","geckodriver.exe");
		try {
			dr=new RemoteWebDriver(new URL(nodeURL),cap);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.get("https://www.facebook.com");
		System.out.println("test2 - stop");
		//dr.get("https://www.facebook.com");
		
	}

}
