package GRID;

import org.testng.annotations.Test;

public class parallel2 {
	@Test
	public void t1() {
		System.out.println("In t1-start");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("In t1-stop");
	}
	@Test
	public void t2() {
		System.out.println("In t2-start");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("In t2-stop");
	}

}
