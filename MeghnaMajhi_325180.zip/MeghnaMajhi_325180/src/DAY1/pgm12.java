package DAY1;
import java.util.Scanner;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float sub1,sub2,sub3,marks;
		Scanner input=new Scanner(System.in);
		sub1=input.nextFloat();
		sub2=input.nextFloat();
		sub3=input.nextFloat();
		marks=(sub1+sub2+sub3)/3;
		System.out.println(marks);
		if(marks>=60) {
			System.out.println("First Class");
		}
		else if(marks>=50 && marks<=60) {
			System.out.println("Second Class");
		}
		else if(marks>=35 && marks<=50) {
			System.out.println("Third Class");
		}
		else {
			System.out.println("Fail");
		}

	}

}
