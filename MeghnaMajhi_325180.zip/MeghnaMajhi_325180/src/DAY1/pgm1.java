package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,n=10,count=0,i,j,k=1;
		for(i=2;i<=n;i++) {
			count=0;
			for(j=2;j<=i/2;j++) {
				if(i%j==0) {
					count++;
					break;
				}
			}
			while(k!=10) {
				if(count==0) {
					System.out.println(i);
					sum+=i;
					++k;
				}
			}}System.out.println(sum);

	}

}
