package DAY1;
import java.util.Scanner;

public class pgm2 {
	public static void main(String[] args) {
		int c,t,n=0;
		Scanner input= new Scanner(System.in);
		int ch=input.nextInt();
		c=ch;
		while(c!=0) {
			t=c%10;
			c=c/10;
			n=n*10+t;
			
		}
		System.out.println(n);
		if(ch==n) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("NP");
		}

}}
