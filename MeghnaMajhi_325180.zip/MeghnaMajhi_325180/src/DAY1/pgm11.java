package DAY1;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5,b=6,c=1;
		int d=(a > b ? ( a > c ? a : c) : (b > c ? b : c));
		System.out.println(d);


		
	}

}
