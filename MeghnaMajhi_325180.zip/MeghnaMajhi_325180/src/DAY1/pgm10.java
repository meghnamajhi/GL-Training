package DAY1;
import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch;
		Scanner inp=new Scanner(System.in);
		ch=inp.next().charAt(0);
		if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U') {
			System.out.println("Vowel");
		}
		else {
			System.out.println("Consonent");
		}
	}

}
