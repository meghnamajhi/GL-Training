package DAY2;
import java.util.Scanner;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner inp=new Scanner(System.in);
		int n=inp.nextInt();
		int sum=0;
		while(n!=0) {
			int r=n%10;
			n=n/10;
			if(r>5) {
				sum=sum+r;
				System.out.println(r);
			}
		}
		System.out.println(sum);

	}

}
