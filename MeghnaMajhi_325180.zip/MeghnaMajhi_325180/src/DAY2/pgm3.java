package DAY2;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,sum=0;
		for(i=10;i<=50;i++) {
			if(i%5==0) {
				if(i==50) {
					System.out.println(i);
				}
				else {
					System.out.print(i +"+");
					
				}
				sum=sum+i;

			}

		}
		System.out.println(sum);

	}

}
