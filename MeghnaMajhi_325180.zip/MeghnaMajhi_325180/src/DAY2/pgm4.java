package DAY2;
import java.util.Scanner;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner inp= new Scanner(System.in);
		int n=inp.nextInt();
		for(int i=0;i<=n;i++) {
			System.out.println(i);
		}

	}

}
