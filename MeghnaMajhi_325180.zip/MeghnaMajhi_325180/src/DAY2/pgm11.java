package DAY2;
import java.util.Scanner;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0,sum=0;
		Scanner inp=new Scanner(System.in);
		int n=inp.nextInt();
		while(count<=10) {
			while(isPrime(n)) {
			++count;
			System.out.println(n);
			sum=sum+n;
		}
		}
	}
	public static boolean isPrime(int x) {
		int i;
		boolean p=true;
		for(i=2;i<=x/2;i++) {
			if(x%i==0) {
				p=false;
				break;
			}
		}return p;
		
	}

}
