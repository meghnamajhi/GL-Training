package DAY2;
import java.util.Scanner;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		int n=input.nextInt();
		for(int i=1;i<=n;i++) {
			for(int j=2*(n-i);j>=1;j--) {
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++) {
				System.out.print(j+" ");
			}
			System.out.println();
		}

	}

}
