package DAY3;

public class student {

	 
		// TODO Auto-generated method stub
		int rollno;
		String name;
		int m1;
		int m2;
		float avg;
		public void average() {
			avg=(m1+m2)/2.0f;
		}

}
