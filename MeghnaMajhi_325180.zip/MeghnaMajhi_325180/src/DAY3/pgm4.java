package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks[][]= {{23,45,76,34},{34,56,83,52},{21,14,48,65}};
		int x[]=new int[4];
		for(int i=0;i<=2;i++) {
			for(int j=0;j<4;j++) {
				x[j]=marks[i][j];
			}
			System.out.println(findMax(x));
		}
		for(int i=0;i<=2;i++) {
			for(int j=0;j<4;j++) {
				System.out.print(marks[i][j]+" ");
			}
			System.out.println();
		}
		

	}
	public static int findMax(int marks[]) {
		int temp=marks[0];
		for(int i=1;i<4;i++) {
			
			if(temp<marks[i]) {
				temp=marks[i];
			}
		}
		return temp;
	}

}
