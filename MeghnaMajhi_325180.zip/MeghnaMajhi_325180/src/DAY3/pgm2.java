package DAY3;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num[]= {21,34,91,59,16,25,29,74,89,82};
		int sum=0;
		for(int i=0;i<=9;i++) {
				sum=sum+checkEven(num[i]);
		}

		System.out.println(sum);
		

	}
	public static int checkEven(int x) {
		if(x%2==0) {
			return x;
		}
		else {
			return 0;
		}
	}

}
