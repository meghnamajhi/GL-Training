package DAY3;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj=new B();
		obj.abc=20;
		obj.xyz=39;
		obj.show1();
		obj.show2();

	}

}
