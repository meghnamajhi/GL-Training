package DAY3;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student rakesh= new student();
		student priya= new student();
		rakesh.rollno=73;
		rakesh.name="Rakesh";
		rakesh.m1=83;
		rakesh.m2=91;
		priya.rollno=52;
		priya.name="priya";
		priya.m1=77;
		priya.m2=99;
		rakesh.average();
		System.out.println(rakesh.avg);
		priya.average();
		System.out.println(priya.avg);
		System.out.println(rakesh.rollno);
		System.out.println(rakesh.name);
		System.out.println(rakesh.m1);
		System.out.println(rakesh.m2);
		System.out.println(priya.rollno);
		System.out.println(priya.name);
		System.out.println(priya.m1);
		System.out.println(priya.m2);

	}

}
