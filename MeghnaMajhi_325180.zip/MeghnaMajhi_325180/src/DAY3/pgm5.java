package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="My name is Meghna Majhi";
		int c=0,p=0;
		while(p!=-1) {
			p=s.indexOf(" ",p+1);
			c++;
		}
		System.out.println("Number of Spaces"+c   ui);

	}

}
